package com.example.domo.models.remoteRepository

import javax.inject.Inject


class SplashScreenRemoteRepository @Inject constructor() {
}