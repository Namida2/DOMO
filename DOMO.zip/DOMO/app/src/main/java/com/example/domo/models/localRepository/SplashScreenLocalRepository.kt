package com.example.domo.models.localRepository


import database.EmployeeDao
import javax.inject.Inject

class SplashScreenLocalRepository @Inject constructor(){

}