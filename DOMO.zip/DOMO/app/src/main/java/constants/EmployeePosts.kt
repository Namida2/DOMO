package constants

object EmployeePosts {
    const val WAITER = "официант"
    const val COOK = "повар"
    const val ADMINISTRATOR = "администратор"
}